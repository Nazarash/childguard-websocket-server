<?php
// ChildGuard WebSocket Server Configuration
// Generated: 2026-02-01

return [
    'port' => 8081,
    'host' => '0.0.0.0',
    'domain' => '',
    'auto_start' => false,
    'log_file' => __DIR__ . '/server.log',
    'pid_file' => __DIR__ . '/server.pid',
];
