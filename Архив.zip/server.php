<?php
require __DIR__ . '/vendor/autoload.php';

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use ChildGuard\StreamingServer;

$port = getenv('PORT') ?: 8080;

echo "🚀 Starting WebSocket server on port {$port}...\n";
echo "📡 Ready to stream video/audio in real-time\n";

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new StreamingServer()
        )
    ),
    $port
);

$server->run();
